# nlp_task_HD
HD nlp garden.py task

# How to run

1. Build the Docker image:
docker build -t garden .

2. Run the Docker container:
docker run garden
